// import { useState } from "react";
// import reactLogo from "./assets/react.svg";
// import viteLogo from "/vite.svg";
// import "./App.css";

// import React from "react";

// Komponen = Function
// Komponen Utama
// 1 Komponen, 1 Return

// 1 Return, 1 Statement
// function App() {
// return <div>
//  <h1> kunjungan guru </h1>
//  <p> pelatihan tersebut ...</p>
// </div>
// }

// contoh salah
// function App() {
// return <h1> Kunjungan Guru </h1>
// <p> Pelatihan tersebut ..... </p>
// }

// function App() {
// return (
//   <>
//     <div>
//       <img src="luffy.png" alt="Gambar Bendera Bajak Laut" />
//       <h1>Monkey D Luffy</h1>
//       <h3>Kaizokuni Ore Wa Naru</h3>
//       <p>
//         Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nobis cumque
//         nulla ratione fugiat illo ipsam veritatis porro quasi vitae
//         voluptatem, illum voluptatibus reprehenderit temporibus sequi, ex
//         error reiciendis doloremque recusandae.
//       </p>
//     </div>
//   </>
// );
// }

// const varJudul = "Monkey D Luffy";
// const varDeskripsi = "Kaizokuni Ore Wa Naru";

// function App() {
//   return (
//     <div>
//       <img src="luffy.png" alt="Gambar Bendera Bajak Laut" />
//       <Judul />
//       <Deskripsi />
//     </div>
//   );
// }

// function Judul() {
//   return <h1>{varJudul}</h1>;
// }

// function Deskripsi() {
//   return <p>{varDeskripsi}</p>;
// }

// function App() {
//   return (
//     <div>
//       <img src="luffy.png" alt="Gambar Bendera Bajak Laut" />
//       <Judul />
//       <Deskripsi />
//     </div>
//   );
// }

// function Judul() {
//   return <h1 className="text-2xl font-bold">Monkey D Luffy</h1>;
// }

// function Deskripsi() {
//   return <p className="text-2xl font-bold">Kaizokuni Ore Wa Naru</p>;
// }
