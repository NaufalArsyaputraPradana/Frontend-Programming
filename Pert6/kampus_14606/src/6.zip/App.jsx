import React from "react";
import AdminLayout from "./Layouts/AdminLayout";

function App() {
  return <AdminLayout />;
}

export default App;
