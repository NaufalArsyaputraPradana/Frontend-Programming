import React from "react";

function Footer() {
  return (
    <footer className="bg-blue-900 text-white text-center py-2">
      &copy; 2024 Admin Dashboard
    </footer>
  );
}

export default Footer;
